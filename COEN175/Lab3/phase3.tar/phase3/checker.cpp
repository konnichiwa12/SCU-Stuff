#include "checker.h"
#include <iostream>
#include "symbol.h"
#include "scope.h"
using namespace std;

static Scope *global = nullptr;
Scope *current = nullptr;
static string redefinition = "redefinition of '%s'";
static string conflicting = "conflicting types for '%s'";
static string redeclared = "redeclaration of '%s'";
static string undeclared = "'%s' undeclared";
static string pointer = "pointer type required for '%s'";
static string incomplete = "'%s' has incomplete type";
set<string> structs;

void openScope() { 
    if (global == nullptr){
        global = new Scope(nullptr);
        current = global;
    }
    else{
        current = new Scope(current);
    }
    cout << "Open Scope" << endl;
}

void closeScope() {
    if (current == global){
        delete current;
        cout << "Close Scope" << endl; 
        current = nullptr;
        global = nullptr;
    }
    else{
        Scope *temp;
        temp = current->enclosing();
        delete current;
        current = temp;
        cout << "Close Scope" << endl; 
    }
    //dont do anything for when there is no global scope
}

void declareFunc(const string &name, const Type &type){
    Symbol *symbol = global->find(name);
    if (symbol == nullptr){
        checkIfStruct(name, type);
        symbol = new Symbol(name, type);
        global->insert(symbol);
        cout << "Declare Function: " << name << ", " << type << endl;
    }
    else if (type != symbol->type()){
        report(conflicting, name);
    }
    else if (type.isStruct() && type.indirection() == 0){
        report(pointer, name);
    }
}

void defineFunc(const string &name, const Type &type){
    Symbol *symbol = global->find(name);
    cout << "Define Function: " << name << ", " << type << endl;
    if (symbol == nullptr){
        checkIfStruct(name, type);
        symbol = new Symbol(name, type);
        global->insert(symbol);
        return;
    }
    else if (symbol->type().parameters() != nullptr){
        report(redefinition, name);
    }
    else if (symbol->type() != type){
        report(conflicting, name);
    }
    else if (type.isStruct() && type.indirection() == 0){
        report(pointer, name);
    }
    symbol->setType(type);
}

void declareVariable(const string &name, const Type &type){
    cout << "Declare Variable: " << name << ", " << type << endl;
    Symbol *symbol = current->find(name);
    if (symbol == nullptr){
        if (type.isCallback()){
            if (type.isStruct() && type.indirection() == 0){
                report(pointer, name);
            }
        }
        else if (type.isStruct() && structs.count(type.specifier()) == 0 && type.indirection() == 0){
            report(incomplete, name);
        }
        symbol = new Symbol(name, type);
        current->insert(symbol);
    }
    else if (current->enclosing() != nullptr){
        report(redeclared, name);
    }
    else if (type != symbol->type()){
        report(conflicting, name);
    }
}

// void declareCallback(const string &name, const Type &type){
//     cout << "Declare Callback: " << name << ", " << type << endl;
//     Symbol *symbol = current->find(name);
//     if (symbol == nullptr){
//         checkIfStruct(name, type);
//         symbol = new Symbol(name, type);
//         current->insert(symbol);
//     }
//     else if (current->enclosing() != nullptr){
//         report(redeclared, name);
//     }
//     else if (type != symbol->type()){
//         report(conflicting, name);
//     }
// }

void declareParameter(const string &name, const Type &type){
    cout << "Declare Parameter: " << name << ", " << type << endl;
    Symbol *symbol = current->find(name);
    if (symbol == nullptr){
        checkIfStruct(name, type);
        symbol = new Symbol(name, type);
        current->insert(symbol);
    }
    else if (symbol != nullptr){
        report(redeclared, name);
    }
}

void checkIfStruct(const string &name, const Type &type){
    if (type.isStruct() && type.indirection() == 0){
        report(pointer,name);
    }
}

void checkID(const string &name){
    cout << "Check ID: " << name << endl;
    if (current->lookup(name) == nullptr){
        report(undeclared, name);
    }
}

void openStruct(const string &name){
    if (structs.count(name) > 0){
        report(redefinition, name);
    }
    openScope();

    // string *s = structs.find(name);
    // if (s == nullptr){
    //     openScope();
    // }
    // else if (s != nullptr){
    //     report(redefinition, symbol);
    // }
}

void closeStruct(const string &name){
    closeScope();
    structs.insert(name);
}