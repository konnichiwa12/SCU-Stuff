# ifndef SYMBOL_H
# define SYMBOL_H
# include <string>
# include <vector>
# include <ostream>
#include "type.h"
#include "symbol.h"


class Symbol{
    typedef std::string string;

    string _name;
	Type _type;

    public: 
        Symbol(const string &name, const Type &type)
            :_name(name), _type(type)
        {
            _name = name;
            _type = type;
        }

        const string& name() const{
            return _name;
        }
        const Type& type() const{
            return _type;
        }
        void setName(const string &name){
            _name = name;
        }
        void setType(const Type &type){
            _type = type;
        }
};

# endif /* SYMBOL_H */