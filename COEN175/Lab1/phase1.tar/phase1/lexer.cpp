#include <cctype>
#include <stdio.h>
#include <iostream>
#include <string>
#include <set>

using namespace std;

set<string> keywords = {"auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else", "enum'", "extern", "float", "for", "goto", "if", "int", "long", "register", "return", "short", "signed", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned", "void", "volatile", "while"};

set<string> operators = {"=","|", "||", "&&", "==", "!=", "<", ">", "<=", ">=", "+", "-", "*", "/", "%", "&", "!", "++", "--", ".", "->", "(", ")", "[", "]", "{", "}", ";", ":", ","};

bool iskeyword(string s){
    if (keywords.count(s)){
        return true;
    }
    return false;
}

bool isoperator(string s){
    if (operators.count(s)){
        return true;
    }
    return false;
}

int main(){
    string buffer;
    char c;
    c = cin.get();
    while (!cin.eof()){

        //whitespace
        if (isspace(c)){
            do{
                buffer += c;
                c = cin.get();
            }while (isspace(c));
        }
        //strings
        else if (c == '\"'){
            do{
                buffer += c;
                c = cin.get();
                if (c == '\\'){
                    buffer += c;
                    c = cin.get();
                    buffer += c;
                    c = cin.get();
                }
            }while (c != '\"');
            c = cin.get();
            buffer += "\"";
            cout << "string:" << buffer << endl;
        }
        //chars
        else if (c == '\''){
            do{
                buffer += c;
                c = cin.get();
            }while (c != '\'');
            c = cin.get();
            buffer += "\'";
            cout << "character:" << buffer << endl;
        }
        //identifiers and keywords
        else if (isalpha(c) || c == '_'){
            do{
                buffer += c;
                c = cin.get();
            }while (isalnum(c) || c == '_');
            if (iskeyword(buffer)){
                cout << "keyword:" << buffer << endl;
            }
            else{
                cout << "identifier:" << buffer << endl;
            }
        }
        //integers
        else if (isdigit(c)){
            do{
                buffer += c;
                c = cin.get();
            }while (isdigit(c));
            cout << "number:" << buffer << endl;
        }
        //coments
        else if (c == '/' && cin.peek() == '*'){
            do{
                cin.get();
            }while (c != '*' && cin.peek() != '/');
            c = cin.get();
            c = cin.get();
        }
        //operators
        else{
            buffer += c;
            string buffer_temp;
            buffer_temp += c;
            buffer_temp += cin.peek();
            if (isoperator(buffer_temp)){
                cout << "operator:" << buffer_temp << endl;
                c = cin.get();
            }
            else if (isoperator(buffer)){
                cout << "operator:" << buffer << endl;
            }
            c = cin.get();
        }
        buffer = "";
    }
}
