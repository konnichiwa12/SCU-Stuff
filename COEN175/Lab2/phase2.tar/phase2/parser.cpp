#include "string.h"
#include "lexer.h"
#include "tokens.h"
#include <iostream>
using namespace std;


int lookahead;
string lexbuf;


static void match(int t)
{
	if (lookahead == t) {
	    lookahead = lexan(lexbuf);
	}
	else {
	    report("error" + t);
	}
}

void exp();
void expList();
void additiveExp();
void declarations();
void statements();
void translationUnit();

bool specifier(){
    if (lookahead == INT){
        match(INT);
    }
    else if (lookahead == CHAR){
        match(CHAR);
    }
    else if (lookahead == STRUCT){
        match(STRUCT);
        if (lookahead == ID){
            match(ID);
            return true;//for type definition
        }
    }
    return false;
}

void pointers(){
    while(lookahead == STAR){
        match(STAR);
    }
}

void primaryExp(bool lp){
    if (lp){
        exp();
        match(RPAREN);
    }
    else{
        if (lookahead == ID){
            match(ID);
        }
        else if (lookahead == CHARACTER){
            match(CHARACTER);
        }
        else if (lookahead == STRING){
            match(STRING);
        }
        else if (lookahead == NUM){
            match(NUM);
        }
    }
}

void expList(){
    exp();
    while (lookahead == COMMA){
        match(COMMA);
        exp();
    }
}

void postfixExp(bool lp){
    primaryExp(lp);
    while(true){
        if (lookahead == LBRACK){
            match(LBRACK);
            exp();
            match(RBRACK);
            cout << "index" << endl;
        }
        else if (lookahead == LPAREN){
            match(LPAREN);
            if (lookahead == RPAREN){
                match(RPAREN);
            }
            else{
                expList();
                match(RPAREN);
            }
            cout << "call" << endl;
        }
        else if (lookahead == DOT){
            match(DOT);
            match(ID);
            cout << "dot" << endl;
        }
        else if (lookahead == ARROW){
            match(ARROW);
            match(ID);
            cout << "arrow" << endl;
        }
        else{
            return;
        }
    }
}

void prefixExp(){
    if (lookahead == LPAREN){
        match(LPAREN);
        if (lookahead == CHAR || lookahead == INT || lookahead == STRUCT){
            specifier();
            pointers();
            match(RPAREN);
            prefixExp();
            cout << "cast" << endl;
        }
        else{
            postfixExp(true);
        }
    }
    else if (lookahead == ADDR){
        match(ADDR);
        prefixExp();
        cout << "addr" << endl;
    }
    else if (lookahead == STAR){
        match(STAR);
        prefixExp();
        cout << "deref" << endl;
    }
    else if (lookahead == NOT){
        match(NOT);
        prefixExp();
        cout << "not" << endl;
    }
    else if (lookahead == MINUS){
        match(MINUS);
        prefixExp();
        cout << "neg" << endl;
    }
    else if (lookahead == SIZEOF){
        match(SIZEOF);
        if (lookahead == LPAREN){
            match(LPAREN);
            if (lookahead == CHAR || lookahead == INT || lookahead == STRUCT){
                specifier();
                pointers();
            }
            else{
                prefixExp();
            }
            match(RPAREN);
        }
        else{
            prefixExp();
        }
        cout << "sizeof" << endl;
    }
    else{
        postfixExp(false);
    }
}

void multiplicativeExp(){
    prefixExp();
    while (lookahead == STAR || lookahead == DIV || lookahead == REM){
        if (lookahead == STAR){
            match(STAR);
            prefixExp();
            cout << "mul" << endl;
        }
        else if (lookahead == DIV){
            match(DIV);
            prefixExp();
            cout << "div" << endl;
        }
        else if (lookahead == REM){
            match(REM);
            prefixExp();
            cout << "rem" << endl;
        }
    }
}

void additiveExp(){
    multiplicativeExp();
    while (lookahead == PLUS || lookahead == MINUS){
        if (lookahead == PLUS){
            match(PLUS);
            multiplicativeExp();
            cout << "add" << endl;
        }
        else if (lookahead == MINUS){
            match(MINUS);
            multiplicativeExp();
            cout << "sub" << endl;
        }
    }
}

void relationalExp(){
    additiveExp();
    while (lookahead == LTN || lookahead == GTN || lookahead == LEQ || lookahead == GEQ){
        if (lookahead == GTN){
            match(GTN);
            additiveExp();
            cout << "gtn" << endl;
        }
        else if (lookahead == GEQ){
            match(GEQ);
            additiveExp();
            cout << "geq" << endl;
        }
        else if (lookahead == LTN){
            match(LTN);
            additiveExp();
            cout << "ltn" << endl;
        }
        else if (lookahead == LEQ){
            match(LEQ);
            additiveExp();
            cout << "leq" << endl;
        }
    }
}

void equalityExp(){
    relationalExp();
    while (lookahead == EQL || lookahead == NEQ){
        if (lookahead == EQL){
            match(EQL);
            relationalExp();
            cout << "eql" << endl;
        }
        else if (lookahead == NEQ){
            match(NEQ);
            relationalExp();
            cout << "neq" << endl;
        }
    }
}

void andExp(){
    equalityExp();
    while (lookahead == AND){
        match(AND);
        equalityExp();
        cout << "and" << endl;
    }
}

void exp(){
    andExp();
    while (lookahead == OR){
        match(OR);
        andExp();
        cout << "or" << endl;
    }
}

void assignment(){
    exp();
    if (lookahead == ASSIGN){
        match(ASSIGN);
        exp();
    }
}

void statement(){
    if (lookahead == LBRACE){
        match(LBRACE);
        declarations();
        statements();
        match(RBRACE);
    }
    else if (lookahead == RETURN){
        match(RETURN);
        exp();
        match(SEMI);
    }
    else if (lookahead == WHILE){
        match(WHILE);
        match(LPAREN);
        exp();
        match(RPAREN);
        statement();
    }
    else if (lookahead == FOR){
        match(FOR);
        match(LPAREN);
        assignment();
        match(SEMI);
        exp();
        match(SEMI);
        assignment();
        match(RPAREN);
        statement();
    }
    else if (lookahead == IF){
        match(IF);
        match(LPAREN);
        exp();
        match(RPAREN);
        statement();
        if (lookahead == ELSE){
            match(ELSE);
            statement();
        }
    }
    else{
        assignment();
        match(SEMI);
    }
}

bool isExp(){
    return (lookahead == LPAREN || lookahead == NOT || lookahead == MINUS || lookahead == ADDR || lookahead == STAR || lookahead == SIZEOF || lookahead == ID || lookahead == NUM || lookahead == STRING || lookahead == CHAR);
}

void statements(){
    while (lookahead != RBRACE && (lookahead == LBRACE || lookahead == RETURN || lookahead == WHILE || lookahead == FOR || lookahead == IF || isExp())){
        statement();
    }
}

void declarator(){
    pointers();
    if (lookahead == LPAREN){
        match(LPAREN);
        match(STAR);
        match(ID);
        match(RPAREN);
        match(LPAREN);
        match(RPAREN);
    }
    else{
        match(ID);
        if (lookahead == LBRACK){
            match(LBRACK);
            match(NUM);
            match(RBRACK);
        }
    }
}

void declaratorList(){
    declarator();
    while (lookahead == COMMA){
        match(COMMA);
        declarator();
    }
}

void declaration(){
    specifier();
    declaratorList();
    match(SEMI);
}

void declarations(){
    while (lookahead == CHAR || lookahead == INT || lookahead == STRUCT){
        declaration();
    }
}

void param(){
    specifier();
    pointers();
    if (lookahead == LPAREN){
        match(LPAREN);
        match(STAR);
        match(ID);
        match(RPAREN);
        match(LPAREN);
        match(RPAREN);
    }
    else{
        match(ID);
    }
}

void paramList(){
    param();
    while (lookahead == COMMA){
        match(COMMA);
        param();
    }
}

void params(){
    if (lookahead == VOID){
        match(VOID);
    }
    else{
        paramList();
    }
}

void funDef(){
    specifier();
    pointers();
    match(ID);
    match(LPAREN);
    param();
    match(RPAREN);
    match(LBRACE);
    declarations();
    statements();
    match(RBRACE);
}

void globalDec(){
    pointers();
    if (lookahead == LPAREN){
        match(LPAREN);
        match(STAR);
        match(ID);
        match(RPAREN);
        match(LPAREN);
        match(RPAREN);
    }
    else if (lookahead == ID){
        match(ID);
        if (lookahead == LPAREN){
            match(LPAREN);
            match(RPAREN);
        }
        else if (lookahead == LBRACK){
            match(LBRACK);
            match(NUM);
            match(RBRACK);
        }
    }
}

void globalDecList(){
    while (lookahead == COMMA){
        match(COMMA);
        globalDec();
    }
}

void globalDeclaration(){
    specifier();
    globalDecList();

}

void typeDef(){
    if (lookahead == LBRACE){
        match(LBRACE);
        declaration();
        declarations();
        match(RBRACE);
        match(SEMI);
    }
    else{
        pointers();
        match(ID);
        match(SEMI);
    }
}

void fog(bool specif){
    if (specif){
        typeDef();
    }
    else{
        pointers();
        if (lookahead == LPAREN){ // function pointer
            match(LPAREN);
            match(STAR);
            match(ID);
            match(RPAREN);
            match(LPAREN);
            match(RPAREN);
            globalDecList();
            match(SEMI);
        }
        else{
            match(ID);
            if (lookahead == LBRACK){
                match(LBRACK);
                match(NUM);
                match(RBRACK);
                globalDecList();
                match(SEMI);
            }
            else if (lookahead == LPAREN){
                match(LPAREN);
                if (lookahead == RPAREN){
                    match(RPAREN);
                    globalDecList();
                    match(SEMI);
                }
                else{
                    params();
                    match(RPAREN);
                    match(LBRACE);
                    declarations();
                    statements();
                    match(RBRACE);
                }
            }
        }
    }
}

void translationUnit(){
    if (lookahead != DONE){
        bool specif = specifier();
        fog(specif);//true = type def, false = global or function
    }
}

int main(){
    lookahead = lexan(lexbuf);
    while (lookahead != DONE){
        translationUnit();
    }
}