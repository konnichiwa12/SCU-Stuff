/*
 * File:	checker.cpp
 *
 * Description:	This file contains the public and private function and
 *		variable definitions for the semantic checker for Simple C.
 *
 *		Extra functionality:
 *		- inserting an undeclared symbol with the error type
 */

# include <map>
# include <set>
# include <iostream>
# include <string>
# include "lexer.h"
# include "checker.h"
# include "Symbol.h"
# include "Scope.h"
# include "Type.h"


using namespace std;

static set<string> functions;
static map<string,Scope *> fields;
static Scope *outermost, *toplevel;
static const Type error;


static string undeclared = "'%s' undeclared";
static string redefined = "redefinition of '%s'";
static string redeclared = "redeclaration of '%s'";
static string conflicting = "conflicting types for '%s'";
static string incomplete = "'%s' has incomplete type";
static string nonpointer = "pointer type required for '%s'";

static string invalidReturn = "invalid return type";
static string invalidTest = "invalid type for test expression";
static string lvalueRequired = "lvalue required in expression";
static string binary = "invalid operands to binary %s";
static string unary = "invalid operand to unary %s";
static string cast = "invalid operand in cast expression";
static string object = "called object is not a function";
static string args = "invalid arguments to called function";
static string pointer = "using pointer to incomplete type";

# define isStructure(t) (t.isStruct() && t.indirection() == 0)


/*
 * Function:	openScope
 *
 * Description:	Create a scope and make it the new top-level scope.
 */

Scope *openScope()
{
    toplevel = new Scope(toplevel);

    if (outermost == nullptr)
	outermost = toplevel;

    return toplevel;
}


/*
 * Function:	closeScope
 *
 * Description:	Remove the top-level scope, and make its enclosing scope
 *		the new top-level scope.
 */

Scope *closeScope()
{
    Scope *old = toplevel;

    toplevel = toplevel->enclosing();
    return old;
}


/*
 * Function:	openStruct
 *
 * Description:	Open a scope for a structure with the specified name.  If a
 *		structure with the same name is already defined, delete it.
 */

void openStruct(const string &name)
{
    if (fields.count(name) > 0) {
	delete fields[name];
	fields.erase(name);
	report(redefined, name);
    }

    openScope();
}


/*
 * Function:	closeStruct
 *
 * Description:	Close the scope for the structure with the specified name.
 */

void closeStruct(const string &name)
{
    fields[name] = closeScope();
}


/*
 * Function:	declareSymbol
 *
 * Description:	Declare a symbol with the specified NAME and TYPE.  Any
 *		erroneous redeclaration is discarded.  If a declaration has
 *		multiple errors, only the first error is reported.  To
 *		report multiple errors, remove the "return" statements and,
 *		if desired, the final "else".
 */

void declareSymbol(const string &name, const Type &type, bool isParameter)
{
    Symbol *symbol = toplevel->find(name);

    if (symbol == nullptr)
	toplevel->insert(new Symbol(name, type));
    else if (toplevel != outermost) {
	report(redeclared, name);
	return;
    } else if (type != symbol->type()) {
	report(conflicting, name);
    	return;
    }

    if (isStructure(type)) {
	if (isParameter || type.isCallback() || type.isFunction())
	    report(nonpointer, name);
	else if (fields.count(type.specifier()) == 0)
	    report(incomplete, name);
    }
}


/*
 * Function:	defineFunction
 *
 * Description:	Define a function with the specified NAME and TYPE.  A
 *		function is always defined in the outermost scope.  This
 *		definition always replaces any previous definition or
 *		declaration.  In the case of multiple errors, only the
 *		first error is reported.  To report multiple errors, remove
 *		the "else"s.
 */

Symbol *defineFunction(const string &name, const Type &type)
{
    Symbol *symbol = outermost->find(name);

    if (functions.count(name) > 0)
	report(redefined, name);
    else if (symbol != nullptr && type != symbol->type())
	report(conflicting, name);
    else if (isStructure(type))
	report(nonpointer, name);

    outermost->remove(name);
    delete symbol;

    symbol = new Symbol(name, type);
    outermost->insert(symbol);

    functions.insert(name);
    return symbol;
}


/*
 * Function:	checkIdentifier
 *
 * Description:	Check if NAME is declared.  If it is undeclared, then
 *		declare it as having the error type in order to eliminate
 *		future error messages.
 */

Symbol *checkIdentifier(const string &name)
{
    Symbol *symbol = toplevel->lookup(name);

    if (symbol == nullptr) {
        report(undeclared, name);
        symbol = new Symbol(name, error);
        toplevel->insert(symbol);
    }

    return symbol;
}

bool checkIncompleteStructPtr(const Type &type){
    return type.isPointer() && type.indirection() == 1 && type.isStruct() && fields.count(type.specifier()) == 0;
}

bool checkIncompleteStruct(const Type &type){
    return type.isStruct() && !type.isPointer() && fields.count(type.specifier()) == 0;
}

Type checkLogicalOr(const Type &left, const Type &right){
    if (!left.isError() && !right.isError()){
        if (left.isValue() && right.isValue()){
            return Scalar("int", 0);
        }
        report(binary,"||");
        return error;
    }
    return error;


}

Type checkLogicalAnd(const Type &left, const Type &right){
    if (!left.isError() && !right.isError()){
        if (left.isValue() && right.isValue()){
            return Scalar("int", 0);
        }
        report(binary,"&&");
        return error;
    }
    return error;


}

Type checkEqualityExpression(const Type &left, const Type &right, const string &op){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (promote1.isCompatibleWith(promote2)){
            return Scalar("int", 0);
        }
        report(binary,op);
        return error;
    }
    return error;


}

Type checkRelationalExpression(const Type &left, const Type &right, const string &op){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (promote1.isCompatibleWith(promote2)){
            return Scalar("int", 0);
        }
        report(binary,op);
        return error;
    }
    return error;


}

Type checkAdd(const Type &left, const Type &right){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (!checkIncompleteStructPtr(promote1) && !checkIncompleteStructPtr(promote2)){
            if (promote1.isPointer() && promote1.isScalar() && promote2.isInteger()){
                return promote1;
            }
            else if (promote1.isInteger() && promote2.isPointer() && promote2.isScalar()){
                return promote2;
            }
            else if (promote1.isInteger() && promote1.isScalar() && promote2.isInteger() && promote2.isScalar()){
                return Scalar("int", 0);
            }
            report(binary,"+");
            return error;
        }
        report(pointer);
        return error;
    }
    return error;


}

Type checkSub(const Type &left, const Type &right){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (!checkIncompleteStructPtr(promote1) && !checkIncompleteStructPtr(promote2)){
            if (promote1.isInteger() && promote1.isScalar() && promote2.isInteger() && promote2.isScalar()){
                return Scalar("int", 0);
            }
            else if (promote1.isPointer() && promote1.isScalar() && promote2.isInteger() && !promote2.isPointer()){
                return promote1;
            }
            else if (promote1.isPointer() && promote1.isScalar() && promote2.isPointer() && promote2.isScalar() && promote1 == promote2){
                return Scalar("int", 0);
            }
            report(binary,"-");
            return error;
        }
        report(pointer);
        return error;
    }
    return error;


}

Type checkMultDivMod(const Type &left, const Type &right, const string &op){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (promote1.isInteger() && !promote1.isPointer() && promote2.isInteger() && !promote2.isPointer()){
            return Scalar("int", 0);
        }
        report(binary,op);
        return error;
    }
    return error;


}

Type checkNot(const Type &left){
    if (!left.isError()){
        if (left.isValue()){
            return Scalar("int", 0);
        }
        report(unary,"!");
        return error;
    }
    return error;


}

Type checkDash(const Type &left){
    if (!left.isError()){
        Type promote = left.promote();
        if (promote.isInteger() && !promote.isPointer()){
            return Scalar("int", 0);
        }
        report(unary,"-");
        return error;
    }
    return error;


}

Type checkDeref(const Type &left){
    if (!left.isError()){
        Type promote = left.promote();
        if (!checkIncompleteStructPtr(promote)){
            if (promote.isPointer() && promote.isScalar()){
                return Scalar(promote.specifier(), promote.indirection() - 1);
            }
            report(unary,"*");
            return error;
        }
        report(pointer);
        return error;
    }
    return error;


}

Type checkAddr(const Type &left, const bool &lvalue){
    if (!left.isError()){
        if (lvalue){
            if (!left.isCallback()){
                return Scalar(left.specifier(), left.indirection() + 1);
            }
            report(unary,"&");
            return error;
        }
        report(lvalueRequired);
        return error;
    }
    return error;


}

Type checkSizeOf(const Type &left){
    if (!left.isError()){
        if (!left.isFunction()){
            if (!checkIncompleteStruct(left)){
                return Scalar("int", 0);
            }
            report(unary, "sizeof");
            return error;
        }
        report(unary, "sizeof");
        return error;
    }
    return error;


}

Type checkCast(const Type &left, const string &spec, const unsigned &ptrs){
    if (!left.isError()){
        Type promote = left.promote();
        if (promote.isInteger() && !promote.isPointer() && spec == "int" && ptrs == 0){
            return Scalar(spec, ptrs);
        }
        else if (left.isPointer() && left.isScalar() && ptrs > 0){
            return Scalar(spec, ptrs);
        }
        report(cast);
        return error;
    }
    return error;


}

Type checkWhileIfFor(const Type &left, const string &op){
    if (!left.isError()){
        if (left.isValue()){
            return left;
        }
        report(invalidTest);
        return error;
    }
    return error;


}

Type checkReturn(const Type &left, const Type &returnType){
    if (!left.isError()){
        if (left.isCompatibleWith(returnType)){
            return left;
        }
        report(invalidReturn);
        return error;
    }
    return error;


}

Type checkAssignment(const Type &left, const Type &right, const bool &lvalue){
    if (!left.isError() && !right.isError()){
        if (lvalue){
            if (left.isCompatibleWith(right)){
                return left;
            }
            report(binary,"=");
            return error;
        }
        report(lvalueRequired);
        return error;
    }
    return error;


}

Type checkIndex(const Type &left, const Type &right){
    if (!left.isError() && !right.isError()){
        Type promote1 = left.promote();
        Type promote2 = right.promote();
        if (!checkIncompleteStructPtr(promote1)){
            if (promote1.isPointer() && promote1.isScalar() && promote2.isInteger() && !promote2.isPointer()){
                return Scalar(promote1.specifier(), promote1.indirection() - 1);
            }
            report(binary,"[]");
            return error;
        }
        report(pointer);
        return error;
    }
    return error;


}

Type checkStructD(const Type &left, const string &right){
    if (!left.isError()){
        Symbol * symbol = nullptr;
        if (fields.count(left.specifier()) > 0){
            symbol = fields[left.specifier()]->find(right);
        }
        if (!checkIncompleteStruct(left) && left.isScalar() && symbol != nullptr){
            return symbol->type();
        }
        report(binary,".");
        return error;
    }
    return error;

}

Type checkStructI(const Type &left, const string &right){
    if (!left.isError()){
        Type promoted = left.promote();
        if (promoted.isStruct() && promoted.indirection() == 1 && promoted.isScalar()){
            string specifier = promoted.specifier();
            if (fields.count(specifier) != 0){
                if (fields[specifier]->find(right) != nullptr){
                    return fields[specifier]->find(right)->type();
                }
                report(binary,"->");
                return error;
            }
            report(pointer);
            return error;
        }
        report(binary,"->");
        return error;
    }
    return error;

}

Type checkCall(const Type &left, const Parameters &params){
    if (!left.isError()){
        if (left.isFunction() || left.isCallback()){
            for (unsigned i = 0; i < params.size(); i++){
                if (!params[i].isValue()){
                    report(args);
                    return error;
                }
            }
            if (left.parameters() == nullptr){
                return Scalar(left.specifier(), left.indirection());
            }
            else if (left.parameters()->size() == params.size()){
                for (unsigned i = 0; i < left.parameters()->size(); i++){
                    if (!left.parameters()->at(i).isCompatibleWith(params[i])){
                        report(args);
                        return error;
                    }
                }
                return Scalar(left.specifier(), left.indirection());
            }
            report(args);
            return error;
        }
        report(object);
        return error;
    }
    return error;


}
