/*
 * File:	checker.h
 *
 * Description:	This file contains the public function declarations for the
 *		semantic checker for Simple C.
 */

# ifndef CHECKER_H
# define CHECKER_H
# include <string>
# include "Scope.h"

typedef std::string string;

Scope *openScope();
Scope *closeScope();

void openStruct(const std::string &name);
void closeStruct(const std::string &name);

void declareSymbol(const std::string &name, const Type &type, bool = false);

Symbol *defineFunction(const std::string &name, const Type &type);
Symbol *checkIdentifier(const std::string &name);

Type checkLogicalOr(const Type &left, const Type &right);
Type checkLogicalAnd(const Type &left, const Type &right);
Type checkEqualityExpression(const Type &left, const Type &right, const string &op);
Type checkRelationalExpression(const Type &left, const Type &right, const string &op);
Type checkAdd(const Type &left, const Type &right);
Type checkSub(const Type &left, const Type &right);
Type checkMultDivMod(const Type &left, const Type &right, const string &op);
Type checkNot(const Type &left);
Type checkDash(const Type &left);
Type checkDeref(const Type &left);
Type checkAddr(const Type &left, const bool &lvalue);
Type checkSizeOf(const Type &left);
Type checkCast(const Type &left, const string &spec, const unsigned &ptrs);
Type checkWhileIfFor(const Type &left, const string &op);
Type checkAssignment(const Type &left, const Type &right, const bool &lvalue);
Type checkIndex(const Type &left, const Type &right);
Type checkStructD(const Type &left, const string &right);
Type checkStructI(const Type &left, const string &right);
Type checkCall(const Type &left, const Parameters &params);
Type checkReturn(const Type &left, const Type &funcType);

bool checkIncompleteStructPtr(const Type &type);
bool checkIncompleteStruct(const Type &type);


# endif /* CHECKER_H */
