#include "Tree.h"
#include "Scope.h"
#include "Symbol.h"

# ifndef GENERATOR_H
# define GENERATOR_H

void generateGlobals(Scope *scope);

#endif