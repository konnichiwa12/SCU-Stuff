#include "Tree.h"
#include "Scope.h"
#include "Type.h"
#include <ostream>
#include <iostream>

using namespace std;

static ostream &operator<<(ostream &ostr, Expression *expr){
    expr->operand(ostr);
    return ostr;
}

void Simple::generate(){
    _expr->generate();
}

void Block::generate(){
    for (auto stmt : _stmts){
        stmt->generate();
    }
}

void Assignment::generate(){
    _left->generate();
    _right->generate();
    cout << "\tmovl\t" << _right << ", " << _left << endl;
}

void Call::generate(){
    for (int i = _args.size() - 1; i >= 0; i--){
        _args[i]->generate();
        cout << "\tpushl\t" << _args[i] << endl;
    }
    cout << "\tcall\t" << _expr << endl;
    cout << "\taddl\t" << "$" << _args.size() * 4 << ", " << "\%esp" << endl;
}


void Procedure::generate(){
    unsigned paramLength = _id->type().parameters()->size();
    Symbols s = _body->declarations()->symbols();
    unsigned scopeLength = s.size();
    int offset = 8;

    for (unsigned i = 0; i < paramLength; i++){
        s[i]->_offset = offset;
        offset += s[i]->type().size();
    }

    if (paramLength <= scopeLength){
        offset = 0;
        for (unsigned i = paramLength; i < scopeLength; i++){
            offset -= s[i]->type().size();
            s[i]->_offset = offset;
        }
    }
    cout << _id->name() << ":" << endl;
    cout << "\tpushl\t" << "\%ebp" << endl;
    cout << "\tmovl\t" << "\%esp, \%ebp" << endl;
    cout << "\tsubl\t$" << (-1 * offset) << ", \%esp" << endl;
    _body->generate();
    cout << "\tmovl\t" << "\%ebp, \%esp" << endl;
    cout << "\tpopl\t" << "\%ebp" << endl;
    cout << "\tret" << endl;
}

void generateGlobals(Scope *scope){
    for (unsigned i = 0; i < scope->symbols().size(); i++){
        if (!scope->symbols()[i]->type().isFunction() && !scope->symbols()[i]->type().isError()){
            cout << ".comm\t" << scope->symbols()[i]->name() << "," << scope->symbols()[i]->type().size() << endl;
        }
        else if (scope->symbols()[i]->type().isFunction()){
            cout << ".globl\t" << scope->symbols()[i]->name() << endl;
        }
    }
}

void Identifier::operand(ostream &ostr) const {
    if (_symbol->_offset != 0){
        ostr << _symbol->_offset << "(\%ebp)";
        return;
    }
    ostr << _symbol->name();
}

void Number::operand(ostream &ostr) const {
    ostr << "$" << _value;
}